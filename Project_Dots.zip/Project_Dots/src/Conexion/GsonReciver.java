package Conexion;

import java.awt.*;

public class GsonReciver {
    Point point1;
    Point point2;
    int turn;
    int player;
    int indicator;
    int p1mX,p1mY,p2mX,p2mY;

    public GsonReciver(Point point1, Point point2, int turn, int player, int indicator, int p1mX, int p1mY, int p2mX, int p2mY) {
        this.point1 = point1;
        this.point2 = point2;
        this.turn = turn;
        this.player = player;
        this.indicator = indicator;
        this.p1mX = p1mX;
        this.p1mY = p1mY;
        this.p2mX = p2mX;
        this.p2mY = p2mY;
    }

    public Point getPoint1() {
        return point1;
    }

    public void setPoint1(Point point1) {
        this.point1 = point1;
    }

    public Point getPoint2() {
        return point2;
    }

    public void setPoint2(Point point2) {
        this.point2 = point2;
    }

    public int getTurn() {
        return turn;
    }

    public void setTurn(int turn) {
        this.turn = turn;
    }

    public int getPlayer() {
        return player;
    }

    public void setPlayer(int player) {
        this.player = player;
    }

    public int getIndicator() {
        return indicator;
    }

    public void setIndicator(int indicator) {
        this.indicator = indicator;
    }
}
