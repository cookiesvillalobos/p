package Conexion;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class SecondClient {
    public static void main (String [] args){
        Socket socket = null;
        System.out.println("Vamos a conectarnos");

        //Se abre una conexión en el puerto 1234
        try{
            socket = new Socket("localhost", 1234);
            System.out.println("Conectado");

            BufferedReader inRead = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter outWriter = new PrintWriter(socket.getOutputStream(),true);

            //Lee el campo de juego
            String jsonInput = inRead.readLine();
            Gson gson = new Gson();
            GsonSendServer gsonSendServer;
            gsonSendServer = gson.fromJson(jsonInput,GsonSendServer.class);
            System.out.println(gsonSendServer.getTurn());



        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}
