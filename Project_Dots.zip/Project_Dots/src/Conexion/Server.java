package Conexion;

import Clases.Lists.LinkList;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread{
    private final int serverPort;
    private LinkList<ServerWorker1> workerList = new LinkList<>();

    public Server (int serverPort){
        this.serverPort = serverPort;
    }

    //public LinkList<ServerWorker1> getWorkerList (){
       // return workerList;
    //;}

    @Override
    public void run() {
        try {
            ServerSocket serverSocket = new ServerSocket(serverPort);
            while (true){
                Socket clientSocket = serverSocket.accept();
                ServerWorker1 serverWorker = new ServerWorker1(this,clientSocket);
                workerList.addPrev(serverWorker);
                serverWorker.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
