package Conexion;

import Principal.Principal1;
import com.google.gson.Gson;

import java.io.*;
import java.net.Socket;

public class FirstClient {

    public static void main (String [] args){
        Socket socket = null;
        System.out.println("Vamos a conectarnos");
        int indicator;
        int Turn = 0;

        //Se abre una conexión en el puerto 1234
        try {
            socket = new Socket("localhost", 1234);
            System.out.println("Conectado");

            BufferedReader inRead = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter outWriter = new PrintWriter(socket.getOutputStream(),true);


            // Lee el campo del juego
            String jsonInput = inRead.readLine();
            Gson gson = new Gson();
            System.out.println(jsonInput);
            GsonSendServer gsonSendServer;
            gsonSendServer = gson.fromJson(jsonInput, GsonSendServer.class);
            System.out.println("Recepción ");
            Principal1 principal1 = new Principal1(gsonSendServer.getMatrix(), gsonSendServer.getDotList(), gsonSendServer.getTurn());
            Turn = gsonSendServer.getTurn();

            String jsonOutputLast = "";
            String jsonOutput = "";

            while (true) {

                jsonOutputLast = jsonOutput;
                jsonOutput = gson.toJson(principal1.getWindow().getSheet().getGsonReciver(), GsonReciver.class);
                //System.out.println(jsonOutput);

                if (!jsonOutputLast.equals(jsonOutput) & jsonOutput!=null) {
                    outWriter.println(jsonOutput);
                    System.out.println("No es nulo");
                    jsonInput = inRead.readLine();
                    //System.out.println(jsonInput);
                    gsonSendServer = gson.fromJson(jsonInput, GsonSendServer.class);
                    System.out.println("El turno del cliente " +gsonSendServer.getTurn());
                    System.out.println("Turno " + Turn );
                    if (Turn == 0 ){
                        Turn++;
                    }
                    if (gsonSendServer.getTurn() != 0 && gsonSendServer.getTurn() == Turn) {
                        System.out.println("El turno es dif");
                        principal1.getWindow().getSheet().setMatrix(gsonSendServer.getMatrix());
                        Turn++;
                        System.out.println("El turno despues de sumar" + Turn);
                    }


                }




            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

}
