package Conexion;

import Clases.Dot;
import Clases.Line;
import Clases.Lists.LinkList;
import Clases.Lists.Matrix;
import Clases.Lists.Matrix1;
import Clases.Lot;
import com.google.gson.Gson;
import javafx.print.PageLayout;

import java.awt.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class ServerWorker extends Thread {

    private final Socket clientSocket;
    private final Server server;
    private Matrix1 matrix = new Matrix1();
    private Vector<Dot> DotList = matrix.viewList();
    private GsonSendServer gsonSendServer = new GsonSendServer(matrix, DotList,0,1);
    LinkList<Line> LineUDList;
    LinkList<Line> LineLRList;
    Lot lot = new Lot();
    int TotalPoint;
    int Player1Points;
    int Player2Points;
    int Turn = 0;
    int Player = 1;
    boolean index = false;

    public ServerWorker(Server server, Socket clientSocket) {
        this.server = server;
        this.clientSocket = clientSocket;
        matrix.board2lines();
        LineLRList = matrix.getLineLRList();
        LineUDList = matrix.getLineUDList();
    }

    @Override
    public void run() {
        try {
            handleClientSocket();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void handleClientSocket() throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        String jsonInput = "";
        String jsonInputLast = "";

        while (true) {
            // Enviar matriz
            try {
                gsonSendServer = new GsonSendServer(matrix, DotList,Turn,Player);
                PrintWriter outWriter = new PrintWriter(clientSocket.getOutputStream(), true);
                Gson gson = new Gson();
                String jsonOutput = gson.toJson(gsonSendServer, GsonSendServer.class);
                System.out.println(jsonOutput);
                outWriter.println(jsonOutput);
                /*
                if (index){
                    System.out.println(jsonOutput);
                }
                */
                outWriter.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }

            // recibir linea
            jsonInputLast = jsonInput;
            System.out.println("last " +jsonInputLast);
            jsonInput = in.readLine();

            System.out.println("primero" + jsonInput);
            System.out.println("Primer statement: " + !jsonInput.equals(jsonInputLast));
            String test = jsonInput.substring(0,1);
            System.out.println(test);
            System.out.println(test.equals("{"));
            boolean ho = !jsonInput.equals(jsonInputLast) && test.equals("{");
            System.out.println("All: " + ho );
            if (!jsonInput.equals(jsonInputLast) && test.equals("{")){
                index = true;
                System.out.println("turno 1: "+ Turn);
                System.out.println("Cambiar matriz");
                Turn++;
                System.out.println("turno 2 : "+ Turn);
                Gson gson = new Gson();
                GsonReciver gsonReciver;
                gsonReciver = gson.fromJson(jsonInput, GsonReciver.class);
                if (lot.ju(gsonReciver.p1mX, gsonReciver.p1mY,gsonReciver.p2mX, gsonReciver.p2mY)){
                    System.out.println(gson.toJson(LineLRList) + "A");
                    Point p1 = gsonReciver.point1;
                    Point p2 = gsonReciver.point2;
                    matrix.lines(p1.x,p1.y,p2.x,p2.y,gsonReciver.player,gsonReciver.turn, LineUDList,LineLRList);
                    LineLRList = matrix.getLineLRList();
                    System.out.println(gson.toJson(LineLRList) + "D");
                    LineUDList = matrix.getLineUDList();
                }


            }

        }
    }
}
