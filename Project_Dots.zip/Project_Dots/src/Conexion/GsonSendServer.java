package Conexion;

import Clases.Dot;
import Clases.Lists.Matrix1;

import java.util.Vector;

public class GsonSendServer {
    Matrix1 matrix;
    Vector<Dot> DotList;
    int Turn;
    int Player;

    public GsonSendServer(Matrix1 matrix, Vector<Dot> dotList, int Turn, int Player) {
        this.matrix = matrix;
        DotList = dotList;
        this.Player = Player;
        this.Turn = Turn;
    }

    public Matrix1 getMatrix() {
        return matrix;
    }

    public void setMatrix(Matrix1 matrix) {
        this.matrix = matrix;
    }

    public Vector<Dot> getDotList() {
        return DotList;
    }

    public void setDotList(Vector<Dot> dotList) {
        DotList = dotList;
    }

    public int getTurn() {
        return Turn;
    }

    public void setTurn(int turn) {
        Turn = turn;
    }

    public int getPlayer() {
        return Player;
    }

    public void setPlayer(int player) {
        Player = player;
    }
}
