package Clases.Lists;

import java.awt.*;

public class pruebas {
    public static void main(String[] args){
        Point point = new Point(24,35);
        String string = point.x + "b" + point.y;
        System.out.println(string.substring(2));
    }
}
