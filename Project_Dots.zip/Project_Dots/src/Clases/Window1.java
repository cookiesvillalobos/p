package Clases;

import Clases.Lists.Matrix;
import Clases.Lists.Matrix1;

import javax.swing.*;
import java.util.Vector;

/**
 * Clase que dibuja la ventana y tiene una instancia del cuadro de juego
 */
public class Window1 extends JFrame {
    private final int WIDTH = 700, HEIGH = 600; //Dimensiones de la pantalla
    private BoardGame1 sheet;

    public Window1(Matrix1 matrix, Vector<Dot> DotList, int Turn){
        setTitle("Dots"); //Título de la ventana
        setSize(WIDTH,HEIGH); //Dimensiones
        setLocationRelativeTo(null); //Posición en el centro de la pantalla
        setResizable(false); // No se puede cambiar el tamaño
        sheet = new BoardGame1(matrix, DotList, Turn);
        add(sheet);
    }

    public BoardGame1 getSheet() {
        return sheet;
    }
}
