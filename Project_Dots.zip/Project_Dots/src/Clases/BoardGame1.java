package Clases;

import Clases.Lists.LinkList;
import Clases.Lists.Matrix;
import Clases.Lists.Matrix1;
import Conexion.GsonReciver;
import Conexion.GsonSendServer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import static com.sun.deploy.uitoolkit.ToolkitStore.dispose;

/**
 * Es la clase que se encarga de hacer las cosas en la pantalla y dibujar.
 * Interactúa con las demás clases para hacer los componentes en la pantalla y tener un juego óptimo
 */
public class BoardGame1 extends JPanel implements MouseListener {
    Matrix1 matrix;
    int indicator = 0;
    int TotalPoint = 0;
    int Player1Points = 0;
    int Player2Points = 0;
    int actualPlayer = 1;
    private Vector<Dot> DotList;
    Point p1;
    Point p2;
    private int p1mX, p1mY, p2mX, p2mY;
    private Dot a = new Dot(0,0,0,0);
    private Dot b;
    private int Turn = 0;
    GsonReciver gsonReciver;
    private LinkList<Line> LineUDList;
    private LinkList<Line> LineLRList;
    private LinkList<Figure> FigureList;




    public BoardGame1(Matrix1 matrix, Vector<Dot> DotList, int Turn){
        setBackground(Color.BLACK); //Fondo de la pantalla
        this.addMouseListener(this);
        this.matrix = matrix;
        this.DotList = matrix.viewList();
        this.Turn = Turn;
        LineUDList = matrix.getLineUDList();
        LineLRList = matrix.getLineLRList();
        FigureList = matrix.getFigureList();

    }

    public Matrix1 getMatrix() {
        return matrix;
    }
    public void Lines (){
        System.out.println("Cambiaron las lineas");
        LineUDList = matrix.getLineUDList();
        LineLRList = matrix.getLineLRList();
        FigureList = matrix.getFigureList();
    }


    public void setMatrix(Matrix1 matrix) {

        this.matrix = matrix;
    }

    /**
     * Método para dibujar los componentes
     * @param g lo que se va a dibujar
     */
    public void paintComponent (Graphics g){
        Lines();
        System.out.println("El turno de pintar " + Turn);
        System.out.println("El indicador de pintar "+ indicator);
        if ( Turn ==0) {
            g.setColor(Color.BLACK);
            g.fillRect(1, 1, 692, 592);

            Graphics2D g2 = (Graphics2D) g;
            g2.setColor(Color.YELLOW);
            matrix.board1(g2);
            matrix.board2(g2);
            matrix.board3(g2);

            //System.out.println("Es el turno del jugador 1");
        }
        else {

            int i = 0;
            while (i < 32) {
                Line line;
                line = LineLRList.see(i);
                line.pintar(g);
                i++;
            }
            i = 0;
            while (i < 27) {
                Line line;
                line = LineUDList.see(i);
                line.pintar(g);
                i++;
            }

            i=0;
            while (i<24){
                Figure figure;
                figure = FigureList.see(i);
                figure.paint(g);
                i++;
            }
        }
        /*
        System.out.println("Puntos totales: " + TotalPoint);
        System.out.println("Puntos jugador 1: " + Player1Points);
        System.out.println("Puntos jugador 2: " + Player2Points);
        */




    }

    public int getIndicator() {
        return indicator;
    }

    public GsonReciver getGsonReciver() {
        return gsonReciver;
    }

    /**
     * Método que escucha al mouse y sabe cuando se presionan los botones del mismo para dibujar una línea
     * @param e es el evento o botón presionado
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1) {


            for (Dot dot : DotList) {

                if (new Rectangle(dot.getX(), dot.getY(), 10, 10).contains(e.getPoint())) {
                    System.out.println("Entró");
                    if (p1 == null) {
                        p1 = new Point(dot.getX(), dot.getY());
                        p1mX = dot.getmX();
                        p1mY = dot.getmY();
                        a = dot;
                        break;
                    }
                    //else if (p1.x != dot.getX() || p1.y != dot.getY()) {
                      else {
                        p2 = new Point(dot.getX(), dot.getY());
                        p2mX = dot.getmX();
                        p2mY = dot.getmY();
                        b = dot;
                        indicator++;
                        Turn++;
                        System.out.println(" Turno en el board: " +Turn);
                        gsonReciver = new GsonReciver(p1,p2,Turn,actualPlayer,indicator,p1mX,p1mY,p2mX,p2mY);
                        System.out.println(indicator);

                        }

                        repaint();
                        p1 = null;
                        p2 = null;
                        a = null;
                        b = null;
                        break;
                    }
                }
            }

        }





    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

}