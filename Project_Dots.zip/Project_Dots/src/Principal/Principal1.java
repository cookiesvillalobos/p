package Principal;

import Clases.Dot;
import Clases.Lists.Matrix;
import Clases.Lists.Matrix1;
import Clases.Window;
import Clases.Window1;

import javax.swing.*;
import java.util.Vector;

/**
 * Clase principal
 * Crea la pantalla y tiene una instancia de la ventana
 * Hace que se pueda cerrar la ventana con el botón de la X
 * Es la clase que se corre
 */
public class Principal1 {
    Matrix1 matrix;
    Vector<Dot> DotList;
    Window1 window;
    public Principal1(Matrix1 matrix, Vector<Dot> DotList, int Turn){
        window = new Window1(matrix, DotList, Turn);
        window.setVisible(true);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public Window1 getWindow() {
        return window;
    }


}
